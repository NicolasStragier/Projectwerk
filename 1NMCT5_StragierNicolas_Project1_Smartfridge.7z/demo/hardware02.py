import RPi.GPIO as GPIO
from time import sleep
import datetime
import mysql.connector as mariadb

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

ledgroen = 23
ledrood = 24
ledblauw = 26
lock = 21
knop = 6

#LEDGROEN
GPIO.setup(ledgroen, GPIO.OUT)
GPIO.output(ledgroen, GPIO.LOW)
#LEDROOD
GPIO.setup(ledrood, GPIO.OUT)
GPIO.output(ledrood, GPIO.LOW)
#LEDBLAUW
GPIO.setup(ledblauw, GPIO.OUT)
GPIO.output(ledblauw, GPIO.LOW)
#LOCK
GPIO.setup(lock, GPIO.OUT)
GPIO.output(lock, GPIO.LOW)
#BUTTON
GPIO.setup(knop, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

lijst = [705861867776, 644758420395, 923327707913]

def save_logging(actie, user, drank, aantal):
    try:
        conn = mariadb.connect(database='smartfridgedb', user='project1-admin123', password='Leerling123')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO logging (Loggingid, Actieid, Userid, Drankid, Aantal, Tijd) VALUES (%s, %s, %s, %s, %s, %s)", ('0', actie, user, drank, aantal, datetime.datetime.now()))
        conn.commit()
        #log.debug("Saved sensor {}={} to database".format(name, value))
        return True
    except Exception as e:
        #log.exception("DB update failed: {!s}".format(e))
        pass

def Setup():
        GPIO.output(ledblauw, GPIO.HIGH)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.LOW)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.HIGH)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.LOW)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.HIGH)
        wegschrijven()

def wegschrijven():
    Gesloten = 1
    Bieren = 0
    Colas = 1
    try:
        while GPIO.input(knop) != Gesloten:
            if Bieren > 0:
                # def save_logging(actie, user, drank, aantal)
                save_logging(2, 1, 2, Bieren)  # wegschrijven naar database
            elif Colas > 0:
                save_logging(2, 1, 1, Colas)  # wegschrijven naar db
            sleep(3)
            Setup()
    except KeyboardInterrupt:
        pass

Setup()