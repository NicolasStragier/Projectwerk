#!/usr/bin/env python

import RPi.GPIO as GPIO
import SimpleMFRC522
import pip
import spidev
from time import sleep
import datetime
import mysql.connector as mariadb

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

reader = SimpleMFRC522.SimpleMFRC522()
spi = spidev.SpiDev()
spi.open(0,0)

ledgroen = 23
ledrood = 24
ledblauw = 26
lock = 21
knop = 6

#LEDGROEN
GPIO.setup(ledgroen, GPIO.OUT)
GPIO.output(ledgroen, GPIO.LOW)
#LEDROOD
GPIO.setup(ledrood, GPIO.OUT)
GPIO.output(ledrood, GPIO.LOW)
#LEDBLAUW
GPIO.setup(ledblauw, GPIO.OUT)
GPIO.output(ledblauw, GPIO.LOW)
#LOCK
GPIO.setup(lock, GPIO.OUT)
GPIO.output(lock, GPIO.LOW)
#BUTTON
GPIO.setup(knop, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

lijst = [705861867776, 644758420395, 923327707913]


def save_logging(actie, user, drank, aantal):
    try:
        conn = mariadb.connect(database='smartfridgedb', user='project1-admin123', password='Leerling123')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO logging (Loggingid, Actieid, Userid, Drankid, Aantal, Tijd) VALUES (%s, %s, %s, %s, %s, %s)", ('0', actie, user, drank, aantal, datetime.datetime.now()))
        conn.commit()
        #log.debug("Saved sensor {}={} to database".format(name, value))
        return True
    except Exception as e:
        #log.exception("DB update failed: {!s}".format(e))
        pass



def Setup():
        GPIO.output(ledblauw, GPIO.HIGH)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.LOW)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.HIGH)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.LOW)
        sleep(0.5)
        GPIO.output(ledblauw, GPIO.HIGH)
        # Go to Scannen()
        Scannen()


def read_spi(channel):
        spidata = spi.xfer2([1, (8 + channel) << 4, 0])
        return ((spidata[1] & 3) << 8) + spidata[2]


spi = spidev.SpiDev()
spi.open(0, 1)


def read_spi(channel):
        spidata = spi.xfer2([1, (8 + channel) << 4, 0])
        return ((spidata[1] & 3) << 8 + spidata[2])


def read_spi_b(channel):
        spidata = spi.xfer2([1, (8 + channel) << 4, 0])
        return ((spidata[1] & 3) << 8 + spidata[2])


def Controleer():
        Gesloten = 1
        Open = 0
        Bier1 = 0
        Bier2 = 0
        Bier3 = 0
        Cola1 = 0
        Cola2 = 0
        Cola3 = 0
        try:
                while GPIO.input(knop) != Gesloten:
                        #GPIO.output(lock, GPIO.LOW)
                        data1 = read_spi(0)
                        data2 = read_spi(1)
                        data3 = read_spi(2)
                        data4 = read_spi(3)
                        data5 = read_spi(4)
                        data6 = read_spi(5)
                        #print("Waarde channel 1 = {}".format(data1))
                        #print("Waarde channel 4 = {}" .format(read_spi_b(4)))
                        #print("Waarde channel 2 = {}".format(data2))
                        #print("Waarde channel 3 = {}".format(data3))
                        #sleep(1)
                        if data1 != 0:
                                Cola1 = 1
                        if data2 != 0:
                                Cola2 = 1
                        if data3 != 0:
                                Cola3 = 1
                        if data4 != 0:
                                Bier1 = 1
                        if data5 != 0:
                                Bier2 = 1
                        if data6 != 0:
                                Bier3 = 1
                        sleep(0.5)
                        # If knop is closed
                        GPIO.output(lock, GPIO.LOW)
                        GPIO.output(ledgroen, GPIO.LOW)
                        print("Doorsturen genomen dranken")
                        Bieren = (Bier1 + Bier2 + Bier3)
                        Colas = (Cola1 + Cola2 + Cola3)
                        print("Er zijn {} aantal Bierjtes genomen".format(Bieren))
                        print("er zijn {} aantal Cola's genomen".format(Colas))
                        if Bieren > 0:
                                #def save_logging(actie, user, drank, aantal)
                                save_logging(2, 1, 2, Bieren) #wegschrijven naar database
                        elif Colas < 0:
                                save_logging(2, 1, 1, Colas)#wegschrijven naar db
                        Scannen()

        except KeyboardInterrupt:
                spi.close()
                Scannen()


def Scannen():
        GPIO.output(ledgroen, GPIO.LOW)
        GPIO.output(ledrood, GPIO.LOW)
        print("Looking for cards")
        print("Press Ctrl-C to stop.")

        try:
                while True:

                        id, text = reader.read()
                        print('ID: ' + str(id))
                        print('Functie: ' + str(text))
                        if id in lijst:
                                GPIO.output(ledgroen, GPIO.HIGH)
                                GPIO.output(lock, GPIO.HIGH)
                                sleep(2)
                                GPIO.output(lock, GPIO.LOW)
                                Controleer()
                        else:
                                GPIO.output(ledrood, GPIO.HIGH)
                                sleep(2)
                                Scannen()

        except KeyboardInterrupt:
                GPIO.output(lock, GPIO.LOW)
                GPIO.cleanup()


def Knop():
        # GPIO.add_event_detect(BtnPin, GPIO.FALLING, callback=swLed, bouncetime$
        # status_knop = GPIO.input(knop)
        # while GPIO.input(knop) == 1:
        #       print("Status: 1")
        # while GPIO.input(knop) == 0:
        #       print("Status: 0")
        vorige_status = 0
        while True:
                status_knop = GPIO.input(knop)
                print(status_knop)
                sleep(0.3)


Setup()





