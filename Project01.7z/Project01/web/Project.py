from flask import Flask
from flask import render_template
from flaskext.mysql import MySQL
from flask import session
from flask import request

app = Flask(__name__)


mysql = MySQL(app)

app.config["MYSQL_DATABASE_HOST"] = "localhost"
app.config["MYSQL_DATABASE_DB"] = "smartfridgedb"
app.config["MYSQL_DATABASE_USER"] = "root"
app.config["MYSQL_DATABASE_PASSWORD"] = "Leerling123"

def get_data(sql,params=None):
    conn = mysql.connect()
    cursor = conn.cursor()
    try:
        cursor.execute(sql,params)

    except Exception as ex:
        print("Woops:", ex)

    result = cursor.fetchall()
    dbdata = []
    for data in result:
        dbdata.append(list(data))
    cursor.close()
    conn.close()
    return dbdata

def set_data(sql, params=None):
    conn = mysql.connect()
    cursor = conn.cursor()

    try:
        print(sql)
        cursor.execute(sql, params)
        conn.commit()
        print("SQL uitgevoerd")

    except Exception as e:
        print("Fout bij uitvoeren van sql: {0})".format(e))
        return False

    cursor.close()
    conn.close()

    return True


@app.route('/')
def index():
    aantalbier = get_data('SELECT D.Dranknaam, D.Drankid, Sum(aantal) as Momenteel FROM smartfridgedb.logging as L, smartfridgedb.acties as A, smartfridgedb.users as U, smartfridgedb.dranken as D WHERE L.Actieid = A.Actieid and L.Userid = U.Userid and L.Drankid = D.Drankid and L.Loggingid != 1 and D.Drankid = 2 group by D.Drankid ORDER BY Tijd;')
    aantalblik = get_data('SELECT D.Dranknaam, D.Drankid, Sum(aantal) as Momenteel FROM smartfridgedb.logging as L, smartfridgedb.acties as A, smartfridgedb.users as U, smartfridgedb.dranken as D WHERE L.Actieid = A.Actieid and L.Userid = U.Userid and L.Drankid = D.Drankid and L.Loggingid != 1 and D.Drankid = 1 group by D.Drankid ORDER BY Tijd;')
    logins = get_data('SELECT concat(cast(Voornaam as char), " ", cast(Naam as char)) as Username FROM users')
    passwords = get_data('SELECT RFID FROM users')
    aantal = get_data('SELECT count(concat(cast(Voornaam as char), " ", cast(Naam as char))) as Username FROM users')
    session['login'] = "False"
    session['user'] = ""
    return render_template('login.html', bier = aantalbier, blik = aantalblik, users = logins, passes = passwords, lengte = aantal)

@app.route('/login')
def login():
    return render_template('loginpagina.html')

@app.route('/welkomadmin')
def welkom():
    gegevens = get_data('SELECT L.Loggingid,  A.Actie, concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) as Naam, U.rol, D.Dranknaam, L.Aantal, L.Tijd FROM smartfridgedb.logging as L, smartfridgedb.acties as A, smartfridgedb.users as U, smartfridgedb.dranken as D WHERE L.Actieid = A.Actieid and L.Userid = U.Userid and L.Drankid = D.Drankid ORDER BY L.Loggingid desc;')
    #if session.get('login') == "True":
    return render_template('welkom.html', data=gegevens)
    #else:
     #   return  index()

@app.route('/welkom')
def welkomuser():
    user = session.get('user')
    user2 = 'Bob Debouwer'
    gegevens = get_data('SELECT concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) as Naam, sum(l.aantal) as aantal, d.drankid, d.verkoopprijs, (sum(aantal)*verkoopprijs) as Coupon FROM Users as u, acties as a, logging as l, dranken as d WHERE u.Userid = l.Userid and l.drankid = d.drankid and a.actieid = 3 and concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) = "%s" group by Naam;'%user2)
    colas = get_data('SELECT concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) as Naam, sum(l.aantal) as aantal, d.drankid, d.verkoopprijs, (sum(aantal)*verkoopprijs) as Coupon FROM Users as u, acties as a, logging as l, dranken as d WHERE u.Userid = l.Userid and l.drankid = d.drankid and a.actieid = 3 and concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) = "%s" and d.drankid = 1 group by drankid;'%user2)
    bieren = get_data('SELECT concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) as Naam, sum(l.aantal) as aantal, d.drankid, d.verkoopprijs, (sum(aantal)*verkoopprijs) as Coupon FROM Users as u, acties as a, logging as l, dranken as d WHERE u.Userid = l.Userid and l.drankid = d.drankid and a.actieid = 3 and concat(cast(U.Voornaam as char), " ", cast(U.Naam as char)) = "%s" and d.drankid = 2 group by drankid;' % user2)
    return render_template('welkomuser.html', gebruiker = user, drankverbruik = gegevens, cola = colas, bier = bieren)

@app.route('/users')
def users():
    gegevens = get_data('SELECT * FROM users')
    return render_template('users.html', users = gegevens)



@app.route('/adduser')
def adduser():
    return render_template('adduser.html')

@app.route('/addinguser', methods=['get'])
def addinguser():
    Naam = request.args.get('Name', None)
    Voornaam = request.args.get('Firstname', None)
    Rol = request.args.get('Function', None)
    RFID = request.args.get('RFID', None)
    set_data("insert into smartfridgedb.users (Userid, Naam, Voornaam, Rol, RFID) VALUES (0,%s, %s, %s, %s)", (Naam, Voornaam, Rol, RFID))
    return render_template('adduser.html')

@app.route('/actions')
def actions():
    gegevens = get_data('SELECT * FROM acties')
    return render_template('actions.html', actions = gegevens)

@app.route('/addaction')
def addaction():
    return render_template('addaction.html')

@app.route('/addingaction', methods=['get'])
def addingaction():
    Action = request.args.get('Action', None)
    Discription = request.args.get('Discription', None)
    set_data("insert into smartfridgedb.acties (Actieid, Actie, Beschrijving) VALUES (0,%s, %s)", (Action, Discription))
    return render_template('addaction.html')


if __name__ == '__main__':
    app.secret_key = 'super secret key'  # secret key, anders werkt het niet
    app.config['SESSION_TYPE'] = 'filesystem'
    app.run(debug=True)
